package Week8.Exercise1;

import java.util.List;

public interface Decrypt {
    String decrypt(String line);

    Boolean isThere(String line);
}
